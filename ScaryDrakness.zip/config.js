module.exports = {
    tokens: "8420396420:AAFbzJmpY7evK21JmaFLQAplz4gpgHpSP6A", // ubah jadi token bot mu
    owner: "7788506948", // ubah jadi id tele mu
    port: "2025", // ubah jadi port panel mu
    ipvps: "159.223.92.185" // ubah jadi ipvps mu
};